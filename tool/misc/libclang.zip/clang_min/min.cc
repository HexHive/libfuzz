#include "./aom/aomcx.h"
#include "./aom/aom_codec.h"
#include "./aom/aom.h"
#include "./aom/aom_decoder.h"
#include "./aom/aomdx.h"
#include "./aom/aom_integer.h"
#include "./aom/aom_image.h"
#include "./aom/aom_encoder.h"

int main(int argc, char** argv) {return 0;}